<?php
    
    $con = new mysqli("localhost","root","","angulardb");
    
    $sid = $_REQUEST["emp_id"];
    
    $query = "delete from tblemp where emp_id = $sid "; //where sid='$sid'";
    
    $rows = $con->query($query);

    $query1 = "select * from tblemp";
    
    $rows1 = $con->query($query1);
    
    while ($row = $rows1->fetch_assoc()) {
        
        $pp[] = $row;
    }
    
    echo json_encode($pp);
?>
