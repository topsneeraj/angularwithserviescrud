<?php
	
  if(!empty($_FILES['file'])){
    
   // echo $username = $_POST["username"];
    
    $ext = pathinfo($_FILES['file']['name'],PATHINFO_EXTENSION);
            $image = time().'.'.$ext;
            move_uploaded_file($_FILES["file"]["tmp_name"], 'images/'.$image);
    echo $image." successfully uploaded";


}
else
{


  echo "Invalid File or Empty File";
}

  /*   $qu = "select * from tblemp";
    
     $rows = $con->query($qu);

    while($row = $rows->fetch_assoc())
     {
        $pp[]  = $row;
        
     }
    
    echo json_encode($pp);
   */

?>

