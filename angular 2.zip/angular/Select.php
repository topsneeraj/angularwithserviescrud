<?php
    
    $con = new mysqli("localhost","root","","angulardb");
    
    //$sid = $_REQUEST["sid"];
    
    $query = "select * from tblemp"; //where sid='$sid'";
    
    $rows = $con->query($query);
    
    while ($row = $rows->fetch_assoc()) {
        
        $pp[] = $row;
    }
    
    echo json_encode($pp);
?>
