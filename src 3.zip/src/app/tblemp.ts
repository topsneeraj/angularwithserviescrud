export class Tblemp {
    emp_id :number;
    emp_name :string;
    emp_add :string;
    emp_mob:string;
    
}
