import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Tblemp} from '../tblemp'
import{Router} from '@angular/router';
import {CommonService} from '../common.service'

@Component({
  selector: 'app-listdata',
  templateUrl: './listdata.component.html',
  styleUrls: ['./listdata.component.css']
})
export class ListdataComponent implements OnInit {

  tbllist = new Array<Tblemp>();
  constructor(private http:HttpClient, private rout :Router,private comm:CommonService) { }

  ngOnInit() {

    this.getdata();

  }

  getdata()
  {
  
     this.comm.getdata("http://localhost/angular/select.php").subscribe(resp=>{

       this.tbllist = resp;
     });

  }
  deleterecord(id)
  {

   // alert(id);
   this.comm.deletedata(id,"http://localhost/angular/delete.php").subscribe(resp=>{

     
       console.log(<Tblemp[]>resp);

       this.tbllist = <Tblemp[]>resp;



   });

    


  }
}
