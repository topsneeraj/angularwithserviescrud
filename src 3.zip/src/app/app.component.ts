import { Component } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Tblemp } from './tblemp';
import {CommonService} from './common.service'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo';
  
  

   constructor(private app:HttpClient,private comm:CommonService)
   {
     


   }
  addstudent(fromval)
  {
   var emp_name = fromval.value.empname;
   var emp_add = fromval.value.empadd;
   var emp_mob = fromval.value.empmob;

    var finalobj = new Tblemp();
    finalobj.emp_id = 1;
    finalobj.emp_name = emp_name;
    finalobj.emp_add = emp_add;
    finalobj.emp_mob = emp_mob;
    

   var obj   = {"emp_name":emp_name,"emp_add":emp_add,"emp_mob":emp_mob};

   this.comm.insertdata(finalobj,"http://localhost/angular/indeximage.php").subscribe(resp=>{

         
   console.log(<Tblemp[]>resp);



   });
   


  }
}
