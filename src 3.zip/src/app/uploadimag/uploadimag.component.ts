import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';

 
@Component({
  selector: 'app-uploadimag',
  templateUrl: './uploadimag.component.html',
  styleUrls: ['./uploadimag.component.css']
})
export class UploadimagComponent implements OnInit {


  selectedFile: File;
  constructor(private http:HttpClient) { }

  ngOnInit() {
  }
  onFileChanged(event) {

    this.selectedFile = event.target.files[0]
  }
onUpload() {
  // this.http is the injected HttpClient
  const uploadData = new FormData();
  uploadData.append('file', this.selectedFile, this.selectedFile.name);
  this.http.post("http://localhost/angular/indexfile.php", uploadData)
    .subscribe(res=>{

      console.log("ok"); 

    });

}
}
