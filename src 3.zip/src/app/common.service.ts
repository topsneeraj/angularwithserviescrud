import { Injectable } from '@angular/core';
import {Tblemp} from './tblemp';
import {HttpClient} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private http:HttpClient) { }


   insertdata(obj:Tblemp,ulr:string)
   {
      
     return this.http.post(ulr,obj)

   }

   getdata(url:string)
   {
    return  this.http.get<Tblemp[]>(url);

   }
   getdatabyid(id:string,url:string)
   {
    
     return  this.http.get<Tblemp[]>(url+'?emp_id=' + id);


   }
   updatedata(obj:Tblemp,url:string)
   {
    return this.http.post(url,obj)

   }
   deletedata(id:string,url:string)
   {

    return  this.http.get<Tblemp[]>(url+'?emp_id=' + id);
   }


}
